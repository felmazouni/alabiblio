"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  SlidersHorizontal,
  MapPin,
  Clock,
  Star,
  Volume2,
  Plug,
  Wifi,
  Thermometer,
  Sparkles,
  Lightbulb,
  Train,
  Bus,
  Bike,
  Car,
  RotateCcw,
  Check,
  Calendar,
  X,
} from "lucide-react"
import { cn } from "@/lib/utils"

export interface FiltersState {
  distance: number
  minRating: number
  openNow: boolean
  open24h: boolean
  openWeekends: boolean
  weekendDay: "sabado" | "domingo" | "ambos" | null
  openUntilHour: number | null
  type: ("biblioteca" | "sala_estudio")[]
  transport: ("metro" | "bus" | "bike" | "car")[]
  minAspects: {
    silencio: number
    enchufes: number
    wifi: number
    temperatura: number
    limpieza: number
    iluminacion: number
  }
}

interface FiltersPanelProps {
  filters: FiltersState
  onChange: (filters: FiltersState) => void
  resultCount?: number
}

const defaultFilters: FiltersState = {
  distance: 5,
  minRating: 0,
  openNow: false,
  open24h: false,
  openWeekends: false,
  weekendDay: null,
  openUntilHour: null,
  type: [],
  transport: [],
  minAspects: {
    silencio: 0,
    enchufes: 0,
    wifi: 0,
    temperatura: 0,
    limpieza: 0,
    iluminacion: 0,
  },
}

const transportOptions = [
  { key: "metro", label: "Metro", icon: Train },
  { key: "bus", label: "Bus", icon: Bus },
  { key: "bike", label: "Bici", icon: Bike },
  { key: "car", label: "Coche", icon: Car },
] as const

const aspectOptions = [
  { key: "silencio", label: "Silencio", icon: Volume2 },
  { key: "enchufes", label: "Enchufes", icon: Plug },
  { key: "wifi", label: "WiFi", icon: Wifi },
  { key: "temperatura", label: "Temperatura", icon: Thermometer },
  { key: "limpieza", label: "Limpieza", icon: Sparkles },
  { key: "iluminacion", label: "Iluminacion", icon: Lightbulb },
] as const

const hourOptions = [
  { value: 18, label: "18:00" },
  { value: 19, label: "19:00" },
  { value: 20, label: "20:00" },
  { value: 21, label: "21:00" },
  { value: 22, label: "22:00" },
  { value: 23, label: "23:00" },
  { value: 24, label: "24:00 (Medianoche)" },
]

function FilterSection({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-4">
      <div>
        <h4 className="text-sm font-semibold text-foreground">{title}</h4>
        {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
      </div>
      {children}
    </div>
  )
}

function ToggleChip({ 
  selected, 
  onClick, 
  children,
  icon: Icon,
  size = "default"
}: { 
  selected: boolean; 
  onClick: () => void; 
  children: React.ReactNode;
  icon?: React.ElementType;
  size?: "default" | "sm"
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-2 rounded-full font-medium transition-all border",
        size === "sm" ? "px-3 py-1.5 text-xs" : "px-4 py-2 text-sm",
        selected
          ? "bg-primary text-primary-foreground border-primary shadow-sm"
          : "bg-card text-foreground border-border hover:border-primary/50 hover:bg-muted/50"
      )}
    >
      {Icon && <Icon className={size === "sm" ? "size-3" : "size-4"} />}
      {children}
      {selected && <Check className={size === "sm" ? "size-3" : "size-3.5"} />}
    </button>
  )
}

export function FiltersPanel({ filters, onChange, resultCount }: FiltersPanelProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [localFilters, setLocalFilters] = useState<FiltersState>(filters)

  const activeFiltersCount = [
    filters.distance < 5,
    filters.minRating > 0,
    filters.openNow,
    filters.open24h,
    filters.openWeekends,
    filters.openUntilHour !== null,
    filters.type.length > 0,
    filters.transport.length > 0,
    Object.values(filters.minAspects).some(v => v > 0),
  ].filter(Boolean).length

  const updateLocal = (updates: Partial<FiltersState>) => {
    setLocalFilters(prev => ({ ...prev, ...updates }))
  }

  const handleTypeToggle = (type: "biblioteca" | "sala_estudio") => {
    const current = localFilters.type
    const updated = current.includes(type)
      ? current.filter(t => t !== type)
      : [...current, type]
    updateLocal({ type: updated })
  }

  const handleTransportToggle = (transport: "metro" | "bus" | "bike" | "car") => {
    const current = localFilters.transport
    const updated = current.includes(transport)
      ? current.filter(t => t !== transport)
      : [...current, transport]
    updateLocal({ transport: updated })
  }

  const handleAspectChange = (aspect: string, value: number) => {
    updateLocal({
      minAspects: {
        ...localFilters.minAspects,
        [aspect]: value,
      },
    })
  }

  const handleApply = () => {
    onChange(localFilters)
    setIsOpen(false)
  }

  const handleReset = () => {
    setLocalFilters(defaultFilters)
  }

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open)
    if (open) {
      setLocalFilters(filters)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 border-border hover:bg-muted/50">
          <SlidersHorizontal className="size-4" />
          <span className="hidden sm:inline">Filtros</span>
          {activeFiltersCount > 0 && (
            <Badge className="ml-1 size-5 p-0 flex items-center justify-center bg-primary text-primary-foreground text-xs rounded-full">
              {activeFiltersCount}
            </Badge>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-hidden flex flex-col p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <SlidersHorizontal className="size-5 text-primary" />
              </div>
              <div>
                <DialogTitle className="text-lg">Filtros avanzados</DialogTitle>
                <DialogDescription className="text-sm">
                  Personaliza tu busqueda para encontrar el espacio perfecto
                </DialogDescription>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleReset} className="text-muted-foreground hover:text-foreground gap-1.5">
              <RotateCcw className="size-4" />
              Limpiar
            </Button>
          </div>
        </DialogHeader>

        <Tabs defaultValue="general" className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="mx-6 mt-4 grid grid-cols-3 w-auto">
            <TabsTrigger value="general" className="gap-2">
              <MapPin className="size-4" />
              General
            </TabsTrigger>
            <TabsTrigger value="horarios" className="gap-2">
              <Calendar className="size-4" />
              Horarios
            </TabsTrigger>
            <TabsTrigger value="calidad" className="gap-2">
              <Star className="size-4" />
              Calidad
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-y-auto px-6 py-4">
            <TabsContent value="general" className="mt-0 space-y-6">
              {/* Distance */}
              <FilterSection title="Distancia maxima" description="Define el radio de busqueda desde tu ubicacion">
                <div className="space-y-4 p-4 rounded-xl bg-muted/30 border border-border">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <MapPin className="size-4" />
                      Radio de busqueda
                    </span>
                    <span className="text-lg font-bold text-primary">{localFilters.distance} km</span>
                  </div>
                  <Slider
                    value={[localFilters.distance]}
                    onValueChange={([v]) => updateLocal({ distance: v })}
                    max={10}
                    min={0.5}
                    step={0.5}
                    className="[&_[role=slider]]:bg-primary [&_[role=slider]]:border-primary"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>500m</span>
                    <span>5 km</span>
                    <span>10 km</span>
                  </div>
                </div>
              </FilterSection>

              {/* Type */}
              <FilterSection title="Tipo de espacio" description="Selecciona el tipo de establecimiento">
                <div className="flex flex-wrap gap-2">
                  <ToggleChip
                    selected={localFilters.type.includes("biblioteca")}
                    onClick={() => handleTypeToggle("biblioteca")}
                  >
                    Biblioteca
                  </ToggleChip>
                  <ToggleChip
                    selected={localFilters.type.includes("sala_estudio")}
                    onClick={() => handleTypeToggle("sala_estudio")}
                  >
                    Sala de Estudio
                  </ToggleChip>
                </div>
              </FilterSection>

              {/* Transport */}
              <FilterSection title="Transporte disponible" description="Filtra por opciones de transporte cercanas">
                <div className="flex flex-wrap gap-2">
                  {transportOptions.map(({ key, label, icon }) => (
                    <ToggleChip
                      key={key}
                      selected={localFilters.transport.includes(key)}
                      onClick={() => handleTransportToggle(key)}
                      icon={icon}
                    >
                      {label}
                    </ToggleChip>
                  ))}
                </div>
              </FilterSection>
            </TabsContent>

            <TabsContent value="horarios" className="mt-0 space-y-6">
              {/* Quick toggles */}
              <FilterSection title="Estado actual">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className={cn(
                    "flex items-center justify-between p-4 rounded-xl border transition-all cursor-pointer",
                    localFilters.openNow ? "bg-primary/5 border-primary" : "bg-card border-border hover:border-primary/50"
                  )} onClick={() => updateLocal({ openNow: !localFilters.openNow })}>
                    <div className="flex items-center gap-3">
                      <div className={cn("size-10 rounded-lg flex items-center justify-center", localFilters.openNow ? "bg-primary/10" : "bg-muted")}>
                        <Clock className={cn("size-5", localFilters.openNow ? "text-primary" : "text-muted-foreground")} />
                      </div>
                      <div>
                        <Label className="font-medium cursor-pointer">Abierta ahora</Label>
                        <p className="text-xs text-muted-foreground">Solo espacios abiertos</p>
                      </div>
                    </div>
                    <Switch checked={localFilters.openNow} onCheckedChange={(v) => updateLocal({ openNow: v })} />
                  </div>
                  
                  <div className={cn(
                    "flex items-center justify-between p-4 rounded-xl border transition-all cursor-pointer",
                    localFilters.open24h ? "bg-primary/5 border-primary" : "bg-card border-border hover:border-primary/50"
                  )} onClick={() => updateLocal({ open24h: !localFilters.open24h })}>
                    <div className="flex items-center gap-3">
                      <div className={cn("size-10 rounded-lg flex items-center justify-center", localFilters.open24h ? "bg-primary/10" : "bg-muted")}>
                        <span className={cn("text-sm font-bold", localFilters.open24h ? "text-primary" : "text-muted-foreground")}>24h</span>
                      </div>
                      <div>
                        <Label className="font-medium cursor-pointer">Abierta 24h</Label>
                        <p className="text-xs text-muted-foreground">Horario ininterrumpido</p>
                      </div>
                    </div>
                    <Switch checked={localFilters.open24h} onCheckedChange={(v) => updateLocal({ open24h: v })} />
                  </div>
                </div>
              </FilterSection>

              {/* Weekend filter */}
              <FilterSection title="Horario de fin de semana" description="Filtra por disponibilidad en sabados y domingos">
                <div className={cn(
                  "p-4 rounded-xl border transition-all",
                  localFilters.openWeekends ? "bg-primary/5 border-primary" : "bg-card border-border"
                )}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={cn("size-10 rounded-lg flex items-center justify-center", localFilters.openWeekends ? "bg-primary/10" : "bg-muted")}>
                        <Calendar className={cn("size-5", localFilters.openWeekends ? "text-primary" : "text-muted-foreground")} />
                      </div>
                      <div>
                        <Label className="font-medium">Abierta fines de semana</Label>
                        <p className="text-xs text-muted-foreground">Filtrar por dias especificos</p>
                      </div>
                    </div>
                    <Switch checked={localFilters.openWeekends} onCheckedChange={(v) => updateLocal({ openWeekends: v, weekendDay: v ? "ambos" : null })} />
                  </div>
                  
                  {localFilters.openWeekends && (
                    <div className="space-y-3 pt-3 border-t border-border">
                      <Label className="text-sm text-muted-foreground">Dias especificos</Label>
                      <div className="flex gap-2">
                        <ToggleChip
                          selected={localFilters.weekendDay === "sabado"}
                          onClick={() => updateLocal({ weekendDay: "sabado" })}
                          size="sm"
                        >
                          Sabado
                        </ToggleChip>
                        <ToggleChip
                          selected={localFilters.weekendDay === "domingo"}
                          onClick={() => updateLocal({ weekendDay: "domingo" })}
                          size="sm"
                        >
                          Domingo
                        </ToggleChip>
                        <ToggleChip
                          selected={localFilters.weekendDay === "ambos"}
                          onClick={() => updateLocal({ weekendDay: "ambos" })}
                          size="sm"
                        >
                          Ambos
                        </ToggleChip>
                      </div>
                    </div>
                  )}
                </div>
              </FilterSection>

              {/* Hour filter */}
              <FilterSection title="Hora de cierre minima" description="Encuentra espacios abiertos hasta cierta hora">
                <div className="p-4 rounded-xl bg-card border border-border">
                  <div className="flex items-center gap-4">
                    <div className="size-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
                      <Clock className="size-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <Label className="text-sm font-medium mb-2 block">Abierta al menos hasta</Label>
                      <Select
                        value={localFilters.openUntilHour?.toString() || "any"}
                        onValueChange={(v) => updateLocal({ openUntilHour: v === "any" ? null : parseInt(v) })}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Cualquier hora" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="any">Cualquier hora</SelectItem>
                          {hourOptions.map(({ value, label }) => (
                            <SelectItem key={value} value={value.toString()}>
                              {label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {localFilters.openUntilHour && (
                      <Button variant="ghost" size="icon" className="shrink-0" onClick={() => updateLocal({ openUntilHour: null })}>
                        <X className="size-4" />
                      </Button>
                    )}
                  </div>
                  {localFilters.openWeekends && localFilters.openUntilHour && (
                    <p className="text-xs text-primary mt-3 flex items-center gap-1.5">
                      <Check className="size-3" />
                      Buscando espacios abiertos {localFilters.weekendDay === "sabado" ? "sabados" : localFilters.weekendDay === "domingo" ? "domingos" : "fines de semana"} hasta las {localFilters.openUntilHour}:00
                    </p>
                  )}
                </div>
              </FilterSection>
            </TabsContent>

            <TabsContent value="calidad" className="mt-0 space-y-6">
              {/* Rating */}
              <FilterSection title="Valoracion general" description="Puntuacion minima de los usuarios">
                <div className="p-4 rounded-xl bg-muted/30 border border-border">
                  <div className="flex items-center gap-2 mb-3">
                    <Star className="size-4 text-amber-500 fill-amber-500" />
                    <span className="text-sm font-medium">
                      {localFilters.minRating > 0 ? `${localFilters.minRating}+ estrellas` : "Cualquier valoracion"}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    {[0, 3, 3.5, 4, 4.5].map((rating) => (
                      <button
                        key={rating}
                        onClick={() => updateLocal({ minRating: rating })}
                        className={cn(
                          "flex-1 py-2.5 px-3 rounded-lg text-sm font-medium border transition-all",
                          localFilters.minRating === rating
                            ? "bg-primary text-primary-foreground border-primary shadow-sm"
                            : "bg-card text-foreground border-border hover:border-primary/50"
                        )}
                      >
                        {rating === 0 ? "Todas" : (
                          <span className="flex items-center justify-center gap-1">
                            {rating}
                            <Star className="size-3 fill-current" />
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </FilterSection>

              {/* Aspects */}
              <FilterSection title="Requisitos por aspecto" description="Establece puntuaciones minimas por categoria">
                <div className="grid gap-2">
                  {aspectOptions.map(({ key, label, icon: Icon }) => (
                    <div 
                      key={key} 
                      className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border hover:border-primary/30 transition-all"
                    >
                      <div className="size-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                        <Icon className="size-4 text-muted-foreground" />
                      </div>
                      <span className="text-sm font-medium flex-1">{label}</span>
                      <div className="flex gap-1.5">
                        {[0, 3, 4, 5].map((rating) => (
                          <button
                            key={rating}
                            onClick={() => handleAspectChange(key, rating)}
                            className={cn(
                              "size-9 rounded-lg text-xs font-semibold border transition-all",
                              localFilters.minAspects[key as keyof typeof localFilters.minAspects] === rating
                                ? "bg-primary text-primary-foreground border-primary shadow-sm"
                                : "bg-muted/50 text-foreground border-transparent hover:border-primary/50"
                            )}
                          >
                            {rating === 0 ? "-" : `${rating}+`}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </FilterSection>
            </TabsContent>
          </div>
        </Tabs>

        {/* Actions */}
        <div className="px-6 py-4 border-t border-border bg-muted/30">
          {resultCount !== undefined && (
            <p className="text-sm text-center text-muted-foreground mb-3">
              <span className="font-semibold text-foreground">{resultCount}</span> {resultCount === 1 ? "resultado encontrado" : "resultados encontrados"}
            </p>
          )}
          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={() => setIsOpen(false)}>
              Cancelar
            </Button>
            <Button className="flex-1 bg-primary hover:bg-primary/90" onClick={handleApply}>
              Aplicar filtros
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export { defaultFilters }
