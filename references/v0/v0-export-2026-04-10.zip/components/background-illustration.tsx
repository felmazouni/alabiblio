"use client"

import { cn } from "@/lib/utils"

export function BackgroundIllustration({ className }: { className?: string }) {
  return (
    <div className={cn("fixed inset-0 -z-10 overflow-hidden pointer-events-none", className)}>
      {/* Gradient base */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.03] via-transparent to-accent/[0.03]" />
      
      {/* SVG Illustration - Wireframe style */}
      <svg
        className="absolute inset-0 w-full h-full"
        viewBox="0 0 1440 900"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid slice"
      >
        {/* Grid lines - subtle background */}
        <defs>
          <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M 60 0 L 0 0 0 60" fill="none" className="stroke-primary/[0.03]" strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />

        {/* Person studying - left side */}
        <g className="stroke-primary/[0.08] dark:stroke-primary/[0.15]" strokeWidth="1.5" fill="none">
          {/* Desk */}
          <path d="M80 680 L280 680 L280 690 L80 690 Z" />
          <path d="M100 690 L100 780" />
          <path d="M260 690 L260 780" />
          
          {/* Chair */}
          <path d="M120 720 L120 780 L200 780 L200 720" />
          <path d="M100 680 L100 620 C100 600 220 600 220 620 L220 680" />
          
          {/* Person sitting */}
          <circle cx="160" cy="560" r="30" /> {/* Head */}
          <path d="M160 590 L160 650" /> {/* Spine */}
          <path d="M160 610 L120 660" /> {/* Left arm */}
          <path d="M160 610 L200 640" /> {/* Right arm to laptop */}
          <path d="M160 650 L130 720" /> {/* Left leg */}
          <path d="M160 650 L190 720" /> {/* Right leg */}
          
          {/* Laptop on desk */}
          <path d="M180 640 L240 640 L250 680 L170 680 Z" />
          <path d="M185 645 L235 645 L235 675 L185 675 Z" />
        </g>

        {/* Bookshelf - right side */}
        <g className="stroke-primary/[0.06] dark:stroke-primary/[0.12]" strokeWidth="1.5" fill="none">
          {/* Shelf structure */}
          <rect x="1100" y="200" width="200" height="400" rx="4" />
          <path d="M1100 280 L1300 280" />
          <path d="M1100 360 L1300 360" />
          <path d="M1100 440 L1300 440" />
          <path d="M1100 520 L1300 520" />
          
          {/* Books row 1 */}
          <rect x="1110" y="210" width="15" height="60" />
          <rect x="1130" y="220" width="12" height="50" />
          <rect x="1147" y="215" width="18" height="55" />
          <rect x="1170" y="210" width="10" height="60" />
          <rect x="1185" y="225" width="14" height="45" />
          <rect x="1205" y="210" width="20" height="60" />
          <rect x="1230" y="218" width="12" height="52" />
          
          {/* Books row 2 */}
          <rect x="1115" y="290" width="18" height="60" />
          <rect x="1138" y="295" width="14" height="55" />
          <rect x="1158" y="285" width="12" height="65" />
          <rect x="1175" y="292" width="20" height="58" />
          <rect x="1200" y="288" width="15" height="62" />
          <rect x="1220" y="295" width="22" height="55" />
          <rect x="1248" y="290" width="16" height="60" />
          
          {/* Books row 3 */}
          <rect x="1108" y="370" width="14" height="60" />
          <rect x="1127" y="375" width="18" height="55" />
          <rect x="1150" y="365" width="12" height="65" />
          <rect x="1168" y="372" width="16" height="58" />
          <rect x="1190" y="368" width="20" height="62" />
          <rect x="1215" y="375" width="14" height="55" />
          
          {/* Plant on shelf */}
          <ellipse cx="1270" cy="425" rx="20" ry="8" />
          <path d="M1270 425 L1270 385" />
          <path d="M1255 400 Q1265 380 1270 385" />
          <path d="M1285 400 Q1275 380 1270 385" />
          <path d="M1260 410 Q1268 390 1270 395" />
          <path d="M1280 410 Q1272 390 1270 395" />
        </g>

        {/* Floating window/screen element - top right */}
        <g className="stroke-accent/[0.1] dark:stroke-accent/[0.2]" strokeWidth="1.5" fill="none">
          <rect x="1050" y="80" width="180" height="120" rx="8" />
          <path d="M1050 105 L1230 105" />
          <circle cx="1065" cy="92" r="5" />
          <circle cx="1082" cy="92" r="5" />
          <circle cx="1099" cy="92" r="5" />
          {/* Map icon inside */}
          <rect x="1070" y="120" width="60" height="60" rx="4" />
          <path d="M1090 130 L1090 170" />
          <path d="M1110 130 L1110 170" />
          <circle cx="1100" cy="145" r="8" className="fill-accent/[0.05]" />
          {/* Chart */}
          <rect x="1145" y="125" width="65" height="50" rx="4" />
          <path d="M1155 165 L1165 155 L1180 160 L1195 140" />
        </g>

        {/* Location pins and paths - center */}
        <g className="stroke-primary/[0.07] dark:stroke-primary/[0.14]" strokeWidth="1.5" fill="none">
          {/* Path connecting locations */}
          <path d="M400 400 Q550 350 700 380 Q850 410 950 350" strokeDasharray="8 4" />
          
          {/* Location pin 1 */}
          <g transform="translate(400, 400)">
            <path d="M0 -25 C-15 -25 -20 -10 -20 0 C-20 15 0 35 0 35 C0 35 20 15 20 0 C20 -10 15 -25 0 -25 Z" />
            <circle cx="0" cy="-5" r="7" />
          </g>
          
          {/* Location pin 2 */}
          <g transform="translate(700, 380)">
            <path d="M0 -25 C-15 -25 -20 -10 -20 0 C-20 15 0 35 0 35 C0 35 20 15 20 0 C20 -10 15 -25 0 -25 Z" />
            <circle cx="0" cy="-5" r="7" />
          </g>
          
          {/* Location pin 3 */}
          <g transform="translate(950, 350)">
            <path d="M0 -25 C-15 -25 -20 -10 -20 0 C-20 15 0 35 0 35 C0 35 20 15 20 0 C20 -10 15 -25 0 -25 Z" />
            <circle cx="0" cy="-5" r="7" />
          </g>
        </g>

        {/* Coffee cup - near person */}
        <g className="stroke-primary/[0.06] dark:stroke-primary/[0.12]" strokeWidth="1.5" fill="none" transform="translate(280, 660)">
          <ellipse cx="0" cy="0" rx="15" ry="5" />
          <path d="M-15 0 L-12 20 L12 20 L15 0" />
          <path d="M15 5 Q25 5 25 12 Q25 19 15 19" />
          {/* Steam */}
          <path d="M-5 -5 Q-8 -15 -3 -20" />
          <path d="M5 -5 Q8 -15 3 -20" />
        </g>

        {/* Small decorative elements */}
        <g className="stroke-accent/[0.06] dark:stroke-accent/[0.12]" strokeWidth="1" fill="none">
          {/* Floating dots/circles */}
          <circle cx="500" cy="200" r="4" />
          <circle cx="600" cy="150" r="3" />
          <circle cx="800" cy="250" r="5" />
          <circle cx="350" cy="300" r="3" />
          <circle cx="900" cy="500" r="4" />
          <circle cx="1000" cy="650" r="3" />
          <circle cx="200" cy="450" r="4" />
          
          {/* Small connecting lines */}
          <path d="M500 200 L520 180" />
          <path d="M600 150 L620 170" />
          <path d="M800 250 L820 230" />
        </g>

        {/* Book icon - floating */}
        <g className="stroke-primary/[0.07] dark:stroke-primary/[0.14]" strokeWidth="1.5" fill="none" transform="translate(550, 550)">
          <path d="M-30 -20 L-30 30 L0 20 L30 30 L30 -20 L0 -30 L-30 -20" />
          <path d="M0 -30 L0 20" />
        </g>

        {/* Lamp - on desk */}
        <g className="stroke-accent/[0.08] dark:stroke-accent/[0.15]" strokeWidth="1.5" fill="none" transform="translate(100, 620)">
          <ellipse cx="0" cy="0" rx="12" ry="4" />
          <path d="M0 0 L0 -30" />
          <path d="M-15 -45 L0 -30 L15 -45 L15 -60 L-15 -60 Z" />
        </g>

        {/* Transport icons - bottom */}
        <g className="stroke-primary/[0.05] dark:stroke-primary/[0.1]" strokeWidth="1.5" fill="none">
          {/* Metro icon */}
          <g transform="translate(600, 800)">
            <rect x="-25" y="-15" width="50" height="30" rx="8" />
            <circle cx="-12" cy="15" r="6" />
            <circle cx="12" cy="15" r="6" />
            <path d="M-15 -5 L15 -5" />
          </g>
          
          {/* Bike icon */}
          <g transform="translate(750, 800)">
            <circle cx="-15" cy="5" r="12" />
            <circle cx="15" cy="5" r="12" />
            <path d="M-15 5 L0 -15 L15 5" />
            <path d="M0 -15 L0 -25" />
            <path d="M-5 -25 L5 -25" />
          </g>
          
          {/* Bus icon */}
          <g transform="translate(900, 800)">
            <rect x="-20" y="-20" width="40" height="35" rx="5" />
            <path d="M-20 0 L20 0" />
            <circle cx="-10" cy="15" r="5" />
            <circle cx="10" cy="15" r="5" />
            <rect x="-15" y="-15" width="10" height="10" rx="2" />
            <rect x="5" y="-15" width="10" height="10" rx="2" />
          </g>
        </g>
      </svg>

      {/* Subtle noise texture overlay */}
      <div 
        className="absolute inset-0 opacity-[0.015] dark:opacity-[0.03]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
        }}
      />

      {/* Corner accents */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-radial from-accent/[0.03] to-transparent" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-gradient-radial from-primary/[0.03] to-transparent" />
    </div>
  )
}
