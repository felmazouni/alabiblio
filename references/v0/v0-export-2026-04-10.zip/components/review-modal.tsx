"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Star, Volume2, Plug, Wifi, Thermometer, Sparkles, Lightbulb, Send } from "lucide-react"
import { cn } from "@/lib/utils"

interface ReviewModalProps {
  isOpen: boolean
  onClose: () => void
  libraryName: string
  onSubmit?: (review: ReviewData) => void
}

interface ReviewData {
  overall: number
  aspects: {
    silencio: number
    enchufes: number
    wifi: number
    temperatura: number
    limpieza: number
    iluminacion: number
  }
  comment: string
}

const aspectsConfig = [
  { key: "silencio", label: "Silencio", icon: Volume2, description: "Nivel de ruido en la sala" },
  { key: "enchufes", label: "Enchufes", icon: Plug, description: "Disponibilidad de enchufes" },
  { key: "wifi", label: "WiFi", icon: Wifi, description: "Velocidad y estabilidad de la conexion" },
  { key: "temperatura", label: "Temperatura", icon: Thermometer, description: "Climatizacion del espacio" },
  { key: "limpieza", label: "Limpieza", icon: Sparkles, description: "Estado de limpieza general" },
  { key: "iluminacion", label: "Iluminacion", icon: Lightbulb, description: "Calidad de la iluminacion" },
] as const

function StarSelector({ value, onChange, size = "md" }: { value: number; onChange: (v: number) => void; size?: "sm" | "md" | "lg" }) {
  const [hover, setHover] = useState(0)
  
  const sizeClass = {
    sm: "size-5",
    md: "size-7",
    lg: "size-9"
  }[size]

  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onMouseEnter={() => setHover(star)}
          onMouseLeave={() => setHover(0)}
          onClick={() => onChange(star)}
          className="transition-transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-primary/50 rounded"
        >
          <Star
            className={cn(
              sizeClass,
              "transition-colors",
              (hover || value) >= star
                ? "fill-amber-400 text-amber-400"
                : "text-slate-200 dark:text-slate-700"
            )}
          />
        </button>
      ))}
    </div>
  )
}

function GoogleLogo({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  )
}

export function ReviewModal({ isOpen, onClose, libraryName, onSubmit }: ReviewModalProps) {
  const [overall, setOverall] = useState(0)
  const [aspects, setAspects] = useState<Record<string, number>>({
    silencio: 0,
    enchufes: 0,
    wifi: 0,
    temperatura: 0,
    limpieza: 0,
    iluminacion: 0,
  })
  const [comment, setComment] = useState("")
  const [step, setStep] = useState<"rating" | "success">("rating")

  const handleAspectChange = (key: string, value: number) => {
    setAspects((prev) => ({ ...prev, [key]: value }))
  }

  const handleSubmit = () => {
    if (overall === 0) return
    
    onSubmit?.({
      overall,
      aspects: aspects as ReviewData["aspects"],
      comment,
    })
    
    setStep("success")
    setTimeout(() => {
      onClose()
      // Reset form
      setOverall(0)
      setAspects({
        silencio: 0,
        enchufes: 0,
        wifi: 0,
        temperatura: 0,
        limpieza: 0,
        iluminacion: 0,
      })
      setComment("")
      setStep("rating")
    }, 2000)
  }

  const isValid = overall > 0

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        {step === "rating" ? (
          <>
            <DialogHeader className="pb-2">
              <div className="flex items-center gap-3 mb-2">
                <div className="size-10 rounded-lg bg-white border border-slate-200 dark:border-slate-700 flex items-center justify-center shadow-sm">
                  <GoogleLogo className="size-6" />
                </div>
                <div>
                  <DialogTitle className="text-lg">Valorar biblioteca</DialogTitle>
                  <DialogDescription className="text-sm">
                    Tu opinion ayuda a otros estudiantes
                  </DialogDescription>
                </div>
              </div>
            </DialogHeader>

            <div className="space-y-6">
              {/* Library Name */}
              <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                <p className="font-medium text-foreground text-sm">{libraryName}</p>
              </div>

              {/* Overall Rating */}
              <div className="text-center space-y-3">
                <p className="text-sm font-medium text-foreground">Valoracion general</p>
                <StarSelector value={overall} onChange={setOverall} size="lg" />
                {overall > 0 && (
                  <p className="text-sm text-muted-foreground">
                    {overall === 1 && "Muy mala"}
                    {overall === 2 && "Mala"}
                    {overall === 3 && "Normal"}
                    {overall === 4 && "Buena"}
                    {overall === 5 && "Excelente"}
                  </p>
                )}
              </div>

              {/* Aspect Ratings */}
              <div className="space-y-1">
                <p className="text-sm font-medium text-foreground mb-3">Valoracion por aspectos <span className="text-muted-foreground font-normal">(opcional)</span></p>
                <div className="space-y-3">
                  {aspectsConfig.map(({ key, label, icon: Icon, description }) => (
                    <div key={key} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors">
                      <div className="size-8 rounded-md bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                        <Icon className="size-4 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground">{label}</p>
                        <p className="text-xs text-muted-foreground">{description}</p>
                      </div>
                      <StarSelector value={aspects[key]} onChange={(v) => handleAspectChange(key, v)} size="sm" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Comment */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  Comentario <span className="text-muted-foreground font-normal">(opcional)</span>
                </label>
                <Textarea
                  placeholder="Comparte tu experiencia con otros estudiantes..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={3}
                  className="resize-none"
                />
              </div>

              {/* Submit */}
              <div className="flex gap-3 pt-2">
                <Button variant="outline" className="flex-1" onClick={onClose}>
                  Cancelar
                </Button>
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90" 
                  onClick={handleSubmit}
                  disabled={!isValid}
                >
                  <Send className="size-4 mr-2" />
                  Publicar
                </Button>
              </div>

              {/* Google Attribution */}
              <p className="text-xs text-center text-muted-foreground">
                Las valoraciones se sincronizan con Google Maps
              </p>
            </div>
          </>
        ) : (
          <div className="py-8 text-center space-y-4">
            <div className="size-16 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center">
              <svg className="size-8 text-emerald-600 dark:text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">Gracias por tu valoracion</h3>
              <p className="text-sm text-muted-foreground mt-1">Tu opinion ayuda a mejorar la experiencia de todos</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
