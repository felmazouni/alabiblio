"use client"

import { useState } from "react"
import {
  MapPin,
  Clock,
  Star,
  Train,
  Bus,
  Bike,
  Car,
  AlertTriangle,
  Info,
  ChevronDown,
  ChevronUp,
  Navigation,
  Users,
  Wifi,
  Plug,
  Volume2,
  Thermometer,
  Sparkles,
  Lightbulb,
  ExternalLink,
  ArrowRight,
  Timer,
  ParkingCircle,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface MetroTransport {
  type: "metro"
  origin: string
  destination: string
  travelTime: string
  lines: string[]
}

interface BusTransport {
  type: "bus"
  lineNumber: string
  boardingStop: string
  alightingStop: string
  waitTime: string
  travelTime: string
  isRealtime: boolean
}

interface BikeTransport {
  type: "bike"
  provider: string
  origin: {
    station: string
    availableBikes: number
    distance: string
  }
  destination: {
    station: string
    availableDocks: number
    distance: string
  }
  travelTime: string
  isRealtime: boolean
}

interface CarTransport {
  type: "car"
  travelTime: string
  distance: string
  parkingZone: string
}

type TransportOption = MetroTransport | BusTransport | BikeTransport | CarTransport

interface Review {
  rating: number
  count: number
  aspects: {
    silencio: number
    enchufes: number
    wifi: number
    temperatura: number
    limpieza: number
    iluminacion: number
  }
}

export interface LibraryData {
  id: string
  name: string
  type: "biblioteca" | "sala_estudio"
  address: string
  neighborhood: string
  district: string
  isOpen: boolean
  openUntil?: string
  opensAt?: string
  ranking?: number
  distance?: string
  transport: TransportOption[]
  reviews: Review
  amenities: string[]
  announcement?: {
    type: "info" | "warning" | "alert"
    message: string
  }
  occupancy?: {
    current: number
    max: number
  }
}

interface LibraryCardProps {
  library: LibraryData
  onNavigate?: () => void
  onDetails?: () => void
  onReview?: () => void
  viewMode?: "card" | "list"
}

function TransportIcon({ type }: { type: TransportOption["type"] }) {
  const iconClass = "size-4"
  switch (type) {
    case "metro":
      return <Train className={iconClass} />
    case "bus":
      return <Bus className={iconClass} />
    case "bike":
      return <Bike className={iconClass} />
    case "car":
      return <Car className={iconClass} />
  }
}

function getTransportColors(type: TransportOption["type"]) {
  switch (type) {
    case "metro":
      return {
        bg: "bg-red-50 dark:bg-red-950/30",
        text: "text-red-700 dark:text-red-400",
        border: "border-red-200 dark:border-red-800",
        icon: "text-red-600 dark:text-red-400",
      }
    case "bus":
      return {
        bg: "bg-blue-50 dark:bg-blue-950/30",
        text: "text-blue-700 dark:text-blue-400",
        border: "border-blue-200 dark:border-blue-800",
        icon: "text-blue-600 dark:text-blue-400",
      }
    case "bike":
      return {
        bg: "bg-emerald-50 dark:bg-emerald-950/30",
        text: "text-emerald-700 dark:text-emerald-400",
        border: "border-emerald-200 dark:border-emerald-800",
        icon: "text-emerald-600 dark:text-emerald-400",
      }
    case "car":
      return {
        bg: "bg-amber-50 dark:bg-amber-950/30",
        text: "text-amber-700 dark:text-amber-400",
        border: "border-amber-200 dark:border-amber-800",
        icon: "text-amber-600 dark:text-amber-400",
      }
  }
}

function StarRating({ rating, size = "sm" }: { rating: number; size?: "sm" | "md" }) {
  const stars = []
  const fullStars = Math.floor(rating)
  const hasHalf = rating % 1 >= 0.5

  for (let i = 0; i < 5; i++) {
    if (i < fullStars) {
      stars.push(
        <Star
          key={i}
          className={cn(
            "fill-amber-400 text-amber-400",
            size === "sm" ? "size-3.5" : "size-4"
          )}
        />
      )
    } else if (i === fullStars && hasHalf) {
      stars.push(
        <div key={i} className="relative">
          <Star className={cn("text-slate-200 dark:text-slate-700", size === "sm" ? "size-3.5" : "size-4")} />
          <div className="absolute inset-0 overflow-hidden w-1/2">
            <Star
              className={cn(
                "fill-amber-400 text-amber-400",
                size === "sm" ? "size-3.5" : "size-4"
              )}
            />
          </div>
        </div>
      )
    } else {
      stars.push(
        <Star
          key={i}
          className={cn("text-slate-200 dark:text-slate-700", size === "sm" ? "size-3.5" : "size-4")}
        />
      )
    }
  }

  return <div className="flex items-center gap-0.5">{stars}</div>
}

function OccupancyBar({ current, max }: { current: number; max: number }) {
  const percentage = (current / max) * 100
  const getColor = () => {
    if (percentage < 50) return "bg-emerald-500"
    if (percentage < 80) return "bg-amber-500"
    return "bg-red-500"
  }
  const getLabel = () => {
    if (percentage < 50) return "Baja ocupacion"
    if (percentage < 80) return "Ocupacion media"
    return "Alta ocupacion"
  }

  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Users className="size-4" />
        <span className="text-sm font-medium">{getLabel()}</span>
      </div>
      <div className="flex-1 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all", getColor())}
          style={{ width: `${percentage}%` }}
        />
      </div>
      <span className="text-sm text-muted-foreground font-medium tabular-nums">
        {current}/{max}
      </span>
    </div>
  )
}

function AspectRating({ label, value, icon: Icon }: { label: string; value: number; icon: React.ElementType }) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="size-4 text-muted-foreground" />
      <span className="text-sm text-foreground capitalize flex-1">{label}</span>
      <div className="flex items-center gap-1.5">
        <div className="w-16 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full"
            style={{ width: `${(value / 5) * 100}%` }}
          />
        </div>
        <span className="text-sm text-muted-foreground w-6 text-right tabular-nums">{value.toFixed(1)}</span>
      </div>
    </div>
  )
}

function GoogleLogo({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  )
}

// Compact transport summary for list view
function TransportSummary({ transport }: { transport: TransportOption[] }) {
  const getIcon = (type: TransportOption["type"]) => {
    switch (type) {
      case "metro": return Train
      case "bus": return Bus
      case "bike": return Bike
      case "car": return Car
    }
  }

  return (
    <div className="flex flex-wrap gap-2">
      {transport.map((t, i) => {
        const colors = getTransportColors(t.type)
        const Icon = getIcon(t.type)
        
        let summary = ""
        if (t.type === "metro") summary = `${t.travelTime}`
        else if (t.type === "bus") summary = `${t.lineNumber} (${t.waitTime})`
        else if (t.type === "bike") summary = `${t.travelTime}`
        else if (t.type === "car") summary = `${t.travelTime}`

        return (
          <div
            key={i}
            className={cn(
              "inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium border",
              colors.bg, colors.border, colors.text
            )}
          >
            <Icon className="size-3" />
            <span>{summary}</span>
          </div>
        )
      })}
    </div>
  )
}

function MetroOption({ option }: { option: MetroTransport }) {
  const colors = getTransportColors("metro")
  return (
    <div className={cn("flex items-center gap-4 p-4 rounded-lg border", colors.bg, colors.border)}>
      <div className={cn("size-10 rounded-lg flex items-center justify-center bg-white dark:bg-slate-900 border", colors.border)}>
        <span className={colors.icon}><Train className="size-4" /></span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className={cn("font-medium text-sm", colors.text)}>
            {option.origin}
          </span>
          <ArrowRight className="size-3 text-muted-foreground" />
          <span className={cn("font-medium text-sm", colors.text)}>
            {option.destination}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          {option.lines.map((line) => (
            <span
              key={line}
              className="text-xs px-2 py-0.5 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700 font-medium text-foreground"
            >
              {line}
            </span>
          ))}
        </div>
      </div>
      <div className="text-right">
        <span className={cn("font-bold text-lg tabular-nums", colors.text)}>
          {option.travelTime}
        </span>
        <p className="text-xs text-muted-foreground">trayecto</p>
      </div>
    </div>
  )
}

function BusOption({ option }: { option: BusTransport }) {
  const colors = getTransportColors("bus")
  return (
    <div className={cn("p-4 rounded-lg border", colors.bg, colors.border)}>
      <div className="flex items-center gap-4">
        <div className={cn("size-10 rounded-lg flex items-center justify-center bg-white dark:bg-slate-900 border", colors.border)}>
          <span className={colors.icon}><Bus className="size-4" /></span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className={cn("font-bold text-lg", colors.text)}>{option.lineNumber}</span>
            {option.isRealtime && (
              <Badge className="text-[10px] px-1.5 py-0 h-5 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800">
                EN VIVO
              </Badge>
            )}
          </div>
        </div>
        <div className="text-right flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
            <Timer className="size-4" />
            <span className="font-semibold tabular-nums">{option.waitTime}</span>
            <span className="text-xs text-muted-foreground">espera</span>
          </div>
          <div>
            <span className={cn("font-bold text-lg tabular-nums", colors.text)}>
              {option.travelTime}
            </span>
            <p className="text-xs text-muted-foreground">trayecto</p>
          </div>
        </div>
      </div>
      <div className="mt-3 pl-14 space-y-1.5">
        <div className="flex items-center gap-2 text-sm">
          <div className="size-2 rounded-full bg-emerald-500" />
          <span className="text-muted-foreground">Subida:</span>
          <span className="text-foreground font-medium">{option.boardingStop}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="size-2 rounded-full bg-red-500" />
          <span className="text-muted-foreground">Bajada:</span>
          <span className="text-foreground font-medium">{option.alightingStop}</span>
        </div>
      </div>
    </div>
  )
}

function BikeOption({ option }: { option: BikeTransport }) {
  const colors = getTransportColors("bike")
  return (
    <div className={cn("p-4 rounded-lg border", colors.bg, colors.border)}>
      <div className="flex items-center gap-4 mb-3">
        <div className={cn("size-10 rounded-lg flex items-center justify-center bg-white dark:bg-slate-900 border", colors.border)}>
          <span className={colors.icon}><Bike className="size-4" /></span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={cn("font-medium text-sm", colors.text)}>{option.provider}</span>
            {option.isRealtime && (
              <Badge className="text-[10px] px-1.5 py-0 h-5 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800">
                EN VIVO
              </Badge>
            )}
          </div>
        </div>
        <div className="text-right">
          <span className={cn("font-bold text-lg tabular-nums", colors.text)}>
            {option.travelTime}
          </span>
          <p className="text-xs text-muted-foreground">trayecto</p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-3 pl-14">
        <div className="p-2.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-1.5 mb-1.5">
            <div className="size-2 rounded-full bg-emerald-500" />
            <span className="text-xs font-medium text-muted-foreground uppercase">Origen</span>
          </div>
          <p className="text-sm font-medium text-foreground mb-1">{option.origin.station}</p>
          <div className="flex items-center justify-between text-xs">
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
              {option.origin.availableBikes} bicis
            </span>
            <span className="text-muted-foreground">{option.origin.distance}</span>
          </div>
        </div>
        
        <div className="p-2.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-1.5 mb-1.5">
            <ParkingCircle className="size-3 text-primary" />
            <span className="text-xs font-medium text-muted-foreground uppercase">Destino</span>
          </div>
          <p className="text-sm font-medium text-foreground mb-1">{option.destination.station}</p>
          <div className="flex items-center justify-between text-xs">
            <span className="text-blue-600 dark:text-blue-400 font-semibold">
              {option.destination.availableDocks} anclajes
            </span>
            <span className="text-muted-foreground">{option.destination.distance}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function CarOption({ option }: { option: CarTransport }) {
  const colors = getTransportColors("car")
  return (
    <div className={cn("flex items-center gap-4 p-4 rounded-lg border", colors.bg, colors.border)}>
      <div className={cn("size-10 rounded-lg flex items-center justify-center bg-white dark:bg-slate-900 border", colors.border)}>
        <span className={colors.icon}><Car className="size-4" /></span>
      </div>
      <div className="flex-1 min-w-0">
        <span className={cn("font-medium text-sm", colors.text)}>En coche</span>
        <div className="flex items-center gap-2 mt-0.5 text-sm text-muted-foreground">
          <span>{option.distance}</span>
          <span>|</span>
          <span>{option.parkingZone}</span>
        </div>
      </div>
      <div className="text-right">
        <span className={cn("font-bold text-lg tabular-nums", colors.text)}>
          {option.travelTime}
        </span>
        <p className="text-xs text-muted-foreground">trayecto</p>
      </div>
    </div>
  )
}

function TransportOptionCard({ option }: { option: TransportOption }) {
  switch (option.type) {
    case "metro":
      return <MetroOption option={option} />
    case "bus":
      return <BusOption option={option} />
    case "bike":
      return <BikeOption option={option} />
    case "car":
      return <CarOption option={option} />
  }
}

export function LibraryCard({ library, onNavigate, onDetails, onReview, viewMode = "card" }: LibraryCardProps) {
  const [isTransportExpanded, setIsTransportExpanded] = useState(false)

  // LIST VIEW - Horizontal compact
  if (viewMode === "list") {
    return (
      <Card className="overflow-hidden border-border shadow-sm hover:shadow-md transition-all bg-card">
        <CardContent className="p-0">
          <div className="flex flex-col">
            {/* Main Row */}
            <div className="flex items-stretch">
              {/* Ranking */}
              {library.ranking && (
                <div className="w-14 shrink-0 bg-primary flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-xl">{library.ranking}</span>
                </div>
              )}
              
              {/* Info Section */}
              <div className="flex-1 p-4 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    {/* Badges */}
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <Badge variant="outline" className="text-xs font-medium text-muted-foreground border-border shrink-0">
                        {library.type === "biblioteca" ? "Biblioteca" : "Sala de Estudio"}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={cn(
                          "font-medium text-xs shrink-0",
                          library.isOpen
                            ? "bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
                            : "bg-red-50 dark:bg-red-950/50 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800"
                        )}
                      >
                        <span className={cn("size-1.5 rounded-full mr-1.5", library.isOpen ? "bg-emerald-500" : "bg-red-500")} />
                        {library.isOpen ? "Abierta" : "Cerrada"}
                      </Badge>
                    </div>
                    
                    {/* Name */}
                    <h3 className="text-base font-semibold leading-tight text-foreground mb-1">
                      {library.name}
                    </h3>
                    
                    {/* Address */}
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                      <MapPin className="size-3.5 shrink-0" />
                      <span className="truncate">{library.address}</span>
                      {library.distance && (
                        <>
                          <span className="text-border">|</span>
                          <span className="text-primary font-medium shrink-0">{library.distance}</span>
                        </>
                      )}
                    </div>

                    {/* Quick Stats Row */}
                    <div className="flex items-center gap-4 flex-wrap">
                      {/* Rating */}
                      <div className="flex items-center gap-1.5">
                        <StarRating rating={library.reviews.rating} size="sm" />
                        <span className="font-bold text-sm text-foreground">{library.reviews.rating.toFixed(1)}</span>
                      </div>
                      
                      {/* Schedule */}
                      <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <Clock className="size-3.5" />
                        <span>
                          {library.isOpen ? `Hasta ${library.openUntil}` : `Abre ${library.opensAt}`}
                        </span>
                      </div>
                      
                      {/* Occupancy */}
                      {library.occupancy && (
                        <div className="flex items-center gap-1.5">
                          <Users className="size-3.5 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground tabular-nums">
                            {library.occupancy.current}/{library.occupancy.max}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-2 shrink-0">
                    <Button size="sm" variant="outline" className="border-border" onClick={onDetails}>
                      <ExternalLink className="size-4" />
                    </Button>
                    <Button size="sm" className="bg-primary hover:bg-primary/90" onClick={onNavigate}>
                      <Navigation className="size-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Transport Row */}
            <div className="px-4 pb-4 pt-0">
              <div className="p-3 rounded-lg bg-muted/30 border border-border">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Transporte</span>
                  <button 
                    onClick={() => setIsTransportExpanded(!isTransportExpanded)}
                    className="text-xs text-primary hover:underline flex items-center gap-1"
                  >
                    {isTransportExpanded ? "Ver menos" : "Ver detalles"}
                    {isTransportExpanded ? <ChevronUp className="size-3" /> : <ChevronDown className="size-3" />}
                  </button>
                </div>
                
                {!isTransportExpanded ? (
                  <TransportSummary transport={library.transport} />
                ) : (
                  <div className="space-y-2 mt-3">
                    {library.transport.map((t, i) => (
                      <TransportOptionCard key={i} option={t} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  // CARD VIEW - Full vertical
  return (
    <Card className="overflow-hidden border-border shadow-sm hover:shadow-md transition-all bg-card">
      <CardContent className="p-0">
        {/* Header */}
        <div className="p-5 pb-4">
          <div className="flex items-start gap-4">
            {/* Ranking */}
            {library.ranking && (
              <div className="shrink-0 size-12 rounded-xl bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl shadow-lg shadow-primary/20">
                {library.ranking}
              </div>
            )}
            
            <div className="flex-1 min-w-0">
              {/* Badges */}
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <Badge variant="outline" className="text-xs font-medium text-muted-foreground border-border">
                  {library.type === "biblioteca" ? "Biblioteca" : "Sala de Estudio"}
                </Badge>
                <Badge
                  variant="outline"
                  className={cn(
                    "font-medium text-xs",
                    library.isOpen
                      ? "bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
                      : "bg-red-50 dark:bg-red-950/50 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800"
                  )}
                >
                  <span className={cn("size-1.5 rounded-full mr-1.5", library.isOpen ? "bg-emerald-500" : "bg-red-500")} />
                  {library.isOpen ? "Abierta" : "Cerrada"}
                </Badge>
              </div>
              
              {/* Name */}
              <h3 className="text-lg font-semibold leading-tight text-foreground mb-1.5 text-balance">
                {library.name}
              </h3>
              
              {/* Address */}
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="size-4 shrink-0" />
                <span>{library.address}</span>
                {library.distance && (
                  <>
                    <span className="text-border">|</span>
                    <span className="text-primary font-medium">{library.distance}</span>
                  </>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-0.5 ml-6">
                {library.neighborhood} - {library.district}
              </p>
            </div>
          </div>
        </div>

        {/* Schedule & Occupancy */}
        <div className="px-5 pb-4">
          <div className="p-4 rounded-xl bg-muted/30 border border-border space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm">
                <Clock className="size-4 text-muted-foreground" />
                <span className="text-muted-foreground">Horario:</span>
                <span className="font-medium text-foreground">
                  {library.isOpen ? `Abierta hasta ${library.openUntil}` : `Abre a las ${library.opensAt}`}
                </span>
              </div>
            </div>
            {library.occupancy && (
              <OccupancyBar current={library.occupancy.current} max={library.occupancy.max} />
            )}
          </div>
        </div>

        {/* Reviews */}
        <div className="px-5 pb-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <StarRating rating={library.reviews.rating} size="md" />
              <span className="text-lg font-bold text-foreground">{library.reviews.rating.toFixed(1)}</span>
              <span className="text-sm text-muted-foreground">({library.reviews.count} opiniones)</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="gap-2 border-border hover:bg-muted/50"
              onClick={onReview}
            >
              <GoogleLogo className="size-4" />
              <span className="text-sm">Opinar</span>
            </Button>
          </div>
          
          <div className="grid grid-cols-2 gap-x-6 gap-y-2">
            <AspectRating label="Silencio" value={library.reviews.aspects.silencio} icon={Volume2} />
            <AspectRating label="Enchufes" value={library.reviews.aspects.enchufes} icon={Plug} />
            <AspectRating label="WiFi" value={library.reviews.aspects.wifi} icon={Wifi} />
            <AspectRating label="Temperatura" value={library.reviews.aspects.temperatura} icon={Thermometer} />
            <AspectRating label="Limpieza" value={library.reviews.aspects.limpieza} icon={Sparkles} />
            <AspectRating label="Iluminacion" value={library.reviews.aspects.iluminacion} icon={Lightbulb} />
          </div>
        </div>

        {/* Announcement */}
        {library.announcement && (
          <div className="px-5 pb-4">
            <div className={cn(
              "p-3 rounded-lg border flex items-start gap-3",
              library.announcement.type === "warning" && "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800",
              library.announcement.type === "info" && "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800",
              library.announcement.type === "alert" && "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800"
            )}>
              {library.announcement.type === "warning" && <AlertTriangle className="size-5 text-amber-600 dark:text-amber-400 shrink-0" />}
              {library.announcement.type === "info" && <Info className="size-5 text-blue-600 dark:text-blue-400 shrink-0" />}
              {library.announcement.type === "alert" && <AlertTriangle className="size-5 text-red-600 dark:text-red-400 shrink-0" />}
              <p className={cn(
                "text-sm",
                library.announcement.type === "warning" && "text-amber-800 dark:text-amber-300",
                library.announcement.type === "info" && "text-blue-800 dark:text-blue-300",
                library.announcement.type === "alert" && "text-red-800 dark:text-red-300"
              )}>
                {library.announcement.message}
              </p>
            </div>
          </div>
        )}

        {/* Transport */}
        <div className="px-5 pb-4">
          <button
            onClick={() => setIsTransportExpanded(!isTransportExpanded)}
            className="w-full flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border hover:bg-muted/50 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Train className="size-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">Como llegar</span>
              <span className="text-xs text-muted-foreground">({library.transport.length} opciones)</span>
            </div>
            {isTransportExpanded ? (
              <ChevronUp className="size-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="size-4 text-muted-foreground" />
            )}
          </button>
          
          {isTransportExpanded && (
            <div className="mt-3 space-y-3">
              {library.transport.map((option, index) => (
                <TransportOptionCard key={index} option={option} />
              ))}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="px-5 pb-5 flex gap-3">
          <Button variant="outline" className="flex-1 border-border" onClick={onDetails}>
            <ExternalLink className="size-4 mr-2" />
            Ver detalles
          </Button>
          <Button className="flex-1 bg-primary hover:bg-primary/90" onClick={onNavigate}>
            <Navigation className="size-4 mr-2" />
            Ir ahora
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
