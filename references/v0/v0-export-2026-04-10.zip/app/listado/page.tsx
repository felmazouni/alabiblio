"use client"

import { useState, useEffect, useMemo } from "react"
import Link from "next/link"
import { LibraryCard, type LibraryData } from "@/components/library-card"
import { ReviewModal } from "@/components/review-modal"
import { FiltersPanel, defaultFilters, type FiltersState } from "@/components/filters-panel"
import { BackgroundIllustration } from "@/components/background-illustration"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Moon, Sun, LayoutGrid, List, Search, MapPin, ArrowLeft, BookOpen, X } from "lucide-react"

// Sample data - in real app this would come from an API
const allLibraries: LibraryData[] = [
  {
    id: "1",
    name: "Biblioteca Publica Municipal Pio Baroja (Arganzuela)",
    type: "biblioteca",
    address: "Calle Arganda 12",
    neighborhood: "Acacias",
    district: "Arganzuela",
    isOpen: true,
    openUntil: "21:00",
    ranking: 1,
    distance: "1.7 km",
    transport: [
      { type: "metro", origin: "Atocha", destination: "Piramides", travelTime: "22 min", lines: ["L1", "L5"] },
      { type: "bus", lineNumber: "24", boardingStop: "Estacion de Atocha", alightingStop: "Piramides", waitTime: "3 min", travelTime: "12 min", isRealtime: true },
      { type: "bike", provider: "BiciMAD", origin: { station: "Estacion 80B", availableBikes: 24, distance: "50 m" }, destination: { station: "Estacion 45A", availableDocks: 8, distance: "120 m" }, travelTime: "13 min", isRealtime: true },
      { type: "car", travelTime: "4 min", distance: "1.7 km", parkingZone: "Zona SER Verde" },
    ],
    reviews: { rating: 4.2, count: 128, aspects: { silencio: 4.5, enchufes: 3.8, wifi: 4.0, temperatura: 4.1, limpieza: 4.4, iluminacion: 4.2 } },
    amenities: ["wifi", "enchufes", "silencio"],
    announcement: { type: "warning", message: "Sala infantil cerrada por mantenimiento hasta el 15 de abril" },
    occupancy: { current: 45, max: 80 },
  },
  {
    id: "2",
    name: "Biblioteca Pedro Salinas",
    type: "biblioteca",
    address: "Glorieta de Puerta de Toledo 1",
    neighborhood: "La Latina",
    district: "Centro",
    isOpen: false,
    opensAt: "09:00",
    ranking: 2,
    distance: "2.1 km",
    transport: [
      { type: "metro", origin: "Sol", destination: "Puerta de Toledo", travelTime: "8 min", lines: ["L5"] },
      { type: "bus", lineNumber: "17", boardingStop: "Sol - Arenal", alightingStop: "Puerta de Toledo", waitTime: "5 min", travelTime: "10 min", isRealtime: true },
    ],
    reviews: { rating: 4.7, count: 256, aspects: { silencio: 4.9, enchufes: 4.5, wifi: 4.6, temperatura: 4.3, limpieza: 4.8, iluminacion: 4.7 } },
    amenities: ["wifi", "enchufes", "silencio"],
    occupancy: { current: 0, max: 120 },
  },
  {
    id: "3",
    name: "Sala de Estudio 24h Moncloa",
    type: "sala_estudio",
    address: "Calle Isaac Peral 10",
    neighborhood: "Moncloa",
    district: "Moncloa-Aravaca",
    isOpen: true,
    openUntil: "24h",
    ranking: 3,
    distance: "3.5 km",
    transport: [
      { type: "metro", origin: "Tribunal", destination: "Moncloa", travelTime: "15 min", lines: ["L3", "L6"] },
      { type: "bike", provider: "BiciMAD", origin: { station: "Estacion 12C", availableBikes: 8, distance: "200 m" }, destination: { station: "Estacion 102A", availableDocks: 15, distance: "80 m" }, travelTime: "20 min", isRealtime: true },
    ],
    reviews: { rating: 3.9, count: 89, aspects: { silencio: 4.2, enchufes: 4.8, wifi: 3.5, temperatura: 3.8, limpieza: 4.0, iluminacion: 4.1 } },
    amenities: ["wifi", "enchufes"],
    announcement: { type: "info", message: "Nuevos horarios de apertura desde el 1 de mayo" },
    occupancy: { current: 72, max: 100 },
  },
  {
    id: "4",
    name: "Biblioteca Eugenio Trias",
    type: "biblioteca",
    address: "Casa de Fieras, Parque del Retiro",
    neighborhood: "Retiro",
    district: "Retiro",
    isOpen: true,
    openUntil: "20:30",
    ranking: 4,
    distance: "2.8 km",
    transport: [
      { type: "metro", origin: "Ibiza", destination: "Retiro", travelTime: "5 min", lines: ["L9"] },
      { type: "bus", lineNumber: "C1", boardingStop: "Cibeles", alightingStop: "Retiro", waitTime: "8 min", travelTime: "15 min", isRealtime: true },
    ],
    reviews: { rating: 4.8, count: 312, aspects: { silencio: 4.7, enchufes: 4.2, wifi: 4.5, temperatura: 4.6, limpieza: 4.9, iluminacion: 4.8 } },
    amenities: ["wifi", "enchufes", "silencio"],
    occupancy: { current: 38, max: 60 },
  },
  {
    id: "5",
    name: "Sala de Estudio Intercambiador Principe Pio",
    type: "sala_estudio",
    address: "Paseo de la Florida s/n",
    neighborhood: "Moncloa",
    district: "Moncloa-Aravaca",
    isOpen: true,
    openUntil: "22:00",
    ranking: 5,
    distance: "4.2 km",
    transport: [
      { type: "metro", origin: "Opera", destination: "Principe Pio", travelTime: "6 min", lines: ["L10", "R"] },
      { type: "bus", lineNumber: "39", boardingStop: "Plaza de Espana", alightingStop: "Principe Pio", waitTime: "4 min", travelTime: "8 min", isRealtime: true },
      { type: "car", travelTime: "12 min", distance: "4.2 km", parkingZone: "Parking subterraneo" },
    ],
    reviews: { rating: 3.6, count: 67, aspects: { silencio: 3.2, enchufes: 4.5, wifi: 3.8, temperatura: 3.4, limpieza: 3.7, iluminacion: 3.9 } },
    amenities: ["wifi", "enchufes"],
    occupancy: { current: 85, max: 150 },
  },
  {
    id: "6",
    name: "Biblioteca Maria Moliner",
    type: "biblioteca",
    address: "Calle Sauceda 15",
    neighborhood: "Usera",
    district: "Usera",
    isOpen: true,
    openUntil: "21:00",
    ranking: 6,
    distance: "5.1 km",
    transport: [
      { type: "metro", origin: "Legazpi", destination: "Usera", travelTime: "12 min", lines: ["L6"] },
      { type: "bus", lineNumber: "78", boardingStop: "Legazpi", alightingStop: "Usera Centro", waitTime: "6 min", travelTime: "18 min", isRealtime: true },
    ],
    reviews: { rating: 4.1, count: 94, aspects: { silencio: 4.3, enchufes: 3.9, wifi: 4.0, temperatura: 4.0, limpieza: 4.2, iluminacion: 4.1 } },
    amenities: ["wifi", "enchufes", "silencio"],
    occupancy: { current: 22, max: 50 },
  },
]

export default function ListadoPage() {
  const [isDark, setIsDark] = useState(false)
  const [viewMode, setViewMode] = useState<"card" | "list">("list")
  const [searchQuery, setSearchQuery] = useState("")
  const [filters, setFilters] = useState<FiltersState>(defaultFilters)
  const [reviewModal, setReviewModal] = useState<{ isOpen: boolean; libraryName: string }>({
    isOpen: false,
    libraryName: "",
  })

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [isDark])

  // Filter libraries based on search and filters
  const filteredLibraries = useMemo(() => {
    return allLibraries.filter((library) => {
      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase()
        const matchesSearch = 
          library.name.toLowerCase().includes(query) ||
          library.address.toLowerCase().includes(query) ||
          library.neighborhood.toLowerCase().includes(query) ||
          library.district.toLowerCase().includes(query)
        if (!matchesSearch) return false
      }

      // Rating filter
      if (filters.minRating > 0 && library.reviews.rating < filters.minRating) {
        return false
      }

      // Open now filter
      if (filters.openNow && !library.isOpen) {
        return false
      }

      // 24h filter
      if (filters.open24h && library.openUntil !== "24h") {
        return false
      }

      // Type filter
      if (filters.type.length > 0 && !filters.type.includes(library.type)) {
        return false
      }

      // Transport filter
      if (filters.transport.length > 0) {
        const hasTransport = filters.transport.some(t => 
          library.transport.some(lt => lt.type === t)
        )
        if (!hasTransport) return false
      }

      // Distance filter (simplified - would need real distance data)
      const distanceKm = parseFloat(library.distance?.replace(" km", "") || "0")
      if (distanceKm > filters.distance) {
        return false
      }

      // Aspect filters
      for (const [aspect, minValue] of Object.entries(filters.minAspects)) {
        if (minValue > 0) {
          const libraryValue = library.reviews.aspects[aspect as keyof typeof library.reviews.aspects]
          if (libraryValue < minValue) {
            return false
          }
        }
      }

      return true
    })
  }, [searchQuery, filters])

  const openReviewModal = (libraryName: string) => {
    setReviewModal({ isOpen: true, libraryName })
  }

  const closeReviewModal = () => {
    setReviewModal({ isOpen: false, libraryName: "" })
  }

  const activeFiltersCount = [
    filters.distance < 5,
    filters.minRating > 0,
    filters.openNow,
    filters.open24h,
    filters.openWeekends,
    filters.openUntilHour !== null,
    filters.type.length > 0,
    filters.transport.length > 0,
    Object.values(filters.minAspects).some(v => v > 0),
  ].filter(Boolean).length

  const clearFilters = () => {
    setFilters(defaultFilters)
    setSearchQuery("")
  }

  return (
    <div className="min-h-screen bg-background transition-colors relative">
      <BackgroundIllustration />

      <div className="max-w-5xl mx-auto p-4 sm:p-6 relative">
        {/* Header */}
        <header className="py-4 mb-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="ghost" size="icon" className="mr-1">
                  <ArrowLeft className="size-5" />
                </Button>
              </Link>
              <div className="size-10 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
                <BookOpen className="size-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-foreground">AlaBiblio</h1>
                <p className="text-xs text-muted-foreground">
                  Comunidad de Madrid
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {/* View Toggle */}
              <div className="flex items-center bg-muted rounded-lg p-1">
                <Button
                  variant="ghost"
                  size="sm"
                  className={viewMode === "card" ? "bg-card shadow-sm" : "hover:bg-transparent"}
                  onClick={() => setViewMode("card")}
                >
                  <LayoutGrid className="size-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={viewMode === "list" ? "bg-card shadow-sm" : "hover:bg-transparent"}
                  onClick={() => setViewMode("list")}
                >
                  <List className="size-4" />
                </Button>
              </div>
              
              {/* Dark Mode Toggle */}
              <Button
                variant="outline"
                size="icon"
                onClick={() => setIsDark(!isDark)}
                className="border-border"
              >
                {isDark ? <Sun className="size-4" /> : <Moon className="size-4" />}
              </Button>
            </div>
          </div>

          {/* Search and Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Buscar por nombre, direccion o barrio..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-card border-border"
              />
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1/2 -translate-y-1/2 size-7"
                  onClick={() => setSearchQuery("")}
                >
                  <X className="size-4" />
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="border-border gap-2">
                <MapPin className="size-4" />
                <span className="hidden sm:inline">Cerca de mi</span>
              </Button>
              <FiltersPanel 
                filters={filters} 
                onChange={setFilters} 
                resultCount={filteredLibraries.length}
              />
            </div>
          </div>

          {/* Active Filters Summary */}
          {(activeFiltersCount > 0 || searchQuery) && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm text-muted-foreground">Filtros activos:</span>
              {searchQuery && (
                <Badge variant="secondary" className="gap-1">
                  Busqueda: {searchQuery}
                  <button onClick={() => setSearchQuery("")}><X className="size-3" /></button>
                </Badge>
              )}
              {filters.openNow && (
                <Badge variant="secondary" className="gap-1">
                  Abierta ahora
                  <button onClick={() => setFilters(prev => ({ ...prev, openNow: false }))}><X className="size-3" /></button>
                </Badge>
              )}
              {filters.open24h && (
                <Badge variant="secondary" className="gap-1">
                  24 horas
                  <button onClick={() => setFilters(prev => ({ ...prev, open24h: false }))}><X className="size-3" /></button>
                </Badge>
              )}
              {filters.openWeekends && (
                <Badge variant="secondary" className="gap-1">
                  Fines de semana
                  <button onClick={() => setFilters(prev => ({ ...prev, openWeekends: false, weekendDay: null }))}><X className="size-3" /></button>
                </Badge>
              )}
              {filters.minRating > 0 && (
                <Badge variant="secondary" className="gap-1">
                  {filters.minRating}+ estrellas
                  <button onClick={() => setFilters(prev => ({ ...prev, minRating: 0 }))}><X className="size-3" /></button>
                </Badge>
              )}
              {filters.type.length > 0 && (
                <Badge variant="secondary" className="gap-1">
                  {filters.type.map(t => t === "biblioteca" ? "Bibliotecas" : "Salas").join(", ")}
                  <button onClick={() => setFilters(prev => ({ ...prev, type: [] }))}><X className="size-3" /></button>
                </Badge>
              )}
              {(activeFiltersCount > 0 || searchQuery) && (
                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-xs text-muted-foreground h-6">
                  Limpiar todo
                </Button>
              )}
            </div>
          )}
        </header>

        {/* Results Header */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-foreground">
              {filteredLibraries.length} {filteredLibraries.length === 1 ? "resultado" : "resultados"}
            </h2>
            <p className="text-sm text-muted-foreground">
              Ordenados por relevancia y distancia
            </p>
          </div>
        </div>

        {/* Library List */}
        {filteredLibraries.length > 0 ? (
          <div className="space-y-4">
            {filteredLibraries.map((library, index) => (
              <LibraryCard
                key={library.id}
                library={{ ...library, ranking: index + 1 }}
                viewMode={viewMode}
                onNavigate={() => console.log("Navigate to library")}
                onDetails={() => console.log("Show details")}
                onReview={() => openReviewModal(library.name)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="size-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Search className="size-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              No se encontraron resultados
            </h3>
            <p className="text-muted-foreground mb-4">
              Prueba a modificar los filtros o la busqueda
            </p>
            <Button variant="outline" onClick={clearFilters}>
              Limpiar filtros
            </Button>
          </div>
        )}

        {/* Footer */}
        <footer className="mt-12 py-8 text-center border-t border-border">
          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <BookOpen className="size-5 text-primary" />
            </div>
            <span className="font-semibold text-foreground">AlaBiblio</span>
          </div>
          <p className="text-sm text-muted-foreground mb-2">
            Proyecto de la Comunidad de Madrid
          </p>
          <p className="text-xs text-muted-foreground">
            Encuentra, compara y valora bibliotecas y salas de estudio
          </p>
        </footer>
      </div>

      {/* Review Modal */}
      <ReviewModal
        isOpen={reviewModal.isOpen}
        onClose={closeReviewModal}
        libraryName={reviewModal.libraryName}
        onSubmit={(review) => console.log("Review submitted:", review)}
      />
    </div>
  )
}
