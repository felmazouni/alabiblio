"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { LibraryCard, type LibraryData } from "@/components/library-card"
import { ReviewModal } from "@/components/review-modal"
import { BackgroundIllustration } from "@/components/background-illustration"
import { Button } from "@/components/ui/button"
import { Moon, Sun, LayoutGrid, List, MapPin, ArrowRight, BookOpen, Users, Clock } from "lucide-react"

const sampleLibrary: LibraryData = {
  id: "1",
  name: "Biblioteca Publica Municipal Pio Baroja (Arganzuela)",
  type: "biblioteca",
  address: "Calle Arganda 12",
  neighborhood: "Acacias",
  district: "Arganzuela",
  isOpen: true,
  openUntil: "21:00",
  ranking: 1,
  distance: "1.7 km",
  transport: [
    {
      type: "metro",
      origin: "Atocha",
      destination: "Piramides",
      travelTime: "22 min",
      lines: ["L1", "L5"],
    },
    {
      type: "bus",
      lineNumber: "24",
      boardingStop: "Estacion de Atocha",
      alightingStop: "Piramides - Paseo de las Acacias",
      waitTime: "3 min",
      travelTime: "12 min",
      isRealtime: true,
    },
    {
      type: "bike",
      provider: "BiciMAD",
      origin: {
        station: "Estacion 80B - Atocha",
        availableBikes: 24,
        distance: "50 m",
      },
      destination: {
        station: "Estacion 45A - Acacias",
        availableDocks: 8,
        distance: "120 m",
      },
      travelTime: "13 min",
      isRealtime: true,
    },
    {
      type: "car",
      travelTime: "4 min",
      distance: "1.7 km",
      parkingZone: "Zona SER Verde",
    },
  ],
  reviews: {
    rating: 4.2,
    count: 128,
    aspects: {
      silencio: 4.5,
      enchufes: 3.8,
      wifi: 4.0,
      temperatura: 4.1,
      limpieza: 4.4,
      iluminacion: 4.2,
    },
  },
  amenities: ["wifi", "enchufes", "silencio"],
  announcement: {
    type: "warning",
    message: "Sala infantil cerrada por mantenimiento hasta el 15 de abril",
  },
  occupancy: {
    current: 45,
    max: 80,
  },
}

const sampleLibrary2: LibraryData = {
  id: "2",
  name: "Biblioteca Pedro Salinas",
  type: "biblioteca",
  address: "Glorieta de Puerta de Toledo 1",
  neighborhood: "La Latina",
  district: "Centro",
  isOpen: false,
  opensAt: "09:00",
  ranking: 2,
  distance: "2.1 km",
  transport: [
    {
      type: "metro",
      origin: "Sol",
      destination: "Puerta de Toledo",
      travelTime: "8 min",
      lines: ["L5"],
    },
    {
      type: "bus",
      lineNumber: "17",
      boardingStop: "Sol - Arenal",
      alightingStop: "Puerta de Toledo",
      waitTime: "5 min",
      travelTime: "10 min",
      isRealtime: true,
    },
  ],
  reviews: {
    rating: 4.7,
    count: 256,
    aspects: {
      silencio: 4.9,
      enchufes: 4.5,
      wifi: 4.6,
      temperatura: 4.3,
      limpieza: 4.8,
      iluminacion: 4.7,
    },
  },
  amenities: ["wifi", "enchufes", "silencio"],
  occupancy: {
    current: 0,
    max: 120,
  },
}

const sampleSalaEstudio: LibraryData = {
  id: "3",
  name: "Sala de Estudio 24h Moncloa",
  type: "sala_estudio",
  address: "Calle Isaac Peral 10",
  neighborhood: "Moncloa",
  district: "Moncloa-Aravaca",
  isOpen: true,
  openUntil: "24h",
  ranking: 3,
  distance: "3.5 km",
  transport: [
    {
      type: "metro",
      origin: "Tribunal",
      destination: "Moncloa",
      travelTime: "15 min",
      lines: ["L3", "L6"],
    },
    {
      type: "bike",
      provider: "BiciMAD",
      origin: {
        station: "Estacion 12C - Gran Via",
        availableBikes: 8,
        distance: "200 m",
      },
      destination: {
        station: "Estacion 102A - Moncloa",
        availableDocks: 15,
        distance: "80 m",
      },
      travelTime: "20 min",
      isRealtime: true,
    },
  ],
  reviews: {
    rating: 3.9,
    count: 89,
    aspects: {
      silencio: 4.2,
      enchufes: 4.8,
      wifi: 3.5,
      temperatura: 3.8,
      limpieza: 4.0,
      iluminacion: 4.1,
    },
  },
  amenities: ["wifi", "enchufes"],
  announcement: {
    type: "info",
    message: "Nuevos horarios de apertura desde el 1 de mayo",
  },
  occupancy: {
    current: 72,
    max: 100,
  },
}

export default function Home() {
  const [isDark, setIsDark] = useState(false)
  const [viewMode, setViewMode] = useState<"card" | "list">("card")
  const [reviewModal, setReviewModal] = useState<{ isOpen: boolean; libraryName: string }>({
    isOpen: false,
    libraryName: "",
  })

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [isDark])

  const openReviewModal = (libraryName: string) => {
    setReviewModal({ isOpen: true, libraryName })
  }

  const closeReviewModal = () => {
    setReviewModal({ isOpen: false, libraryName: "" })
  }

  const topLibraries = [sampleLibrary, sampleLibrary2, sampleSalaEstudio]

  return (
    <div className="min-h-screen bg-background transition-colors relative">
      <BackgroundIllustration />

      <div className="max-w-4xl mx-auto p-4 sm:p-6 relative">
        {/* Header */}
        <header className="py-6 mb-2">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="size-12 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
                <BookOpen className="size-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">AlaBiblio</h1>
                <p className="text-sm text-muted-foreground">
                  Comunidad de Madrid
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {/* View Toggle */}
              <div className="flex items-center bg-muted rounded-lg p-1">
                <Button
                  variant="ghost"
                  size="sm"
                  className={viewMode === "card" ? "bg-card shadow-sm" : "hover:bg-transparent"}
                  onClick={() => setViewMode("card")}
                >
                  <LayoutGrid className="size-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={viewMode === "list" ? "bg-card shadow-sm" : "hover:bg-transparent"}
                  onClick={() => setViewMode("list")}
                >
                  <List className="size-4" />
                </Button>
              </div>
              
              {/* Dark Mode Toggle */}
              <Button
                variant="outline"
                size="icon"
                onClick={() => setIsDark(!isDark)}
                className="border-border"
              >
                {isDark ? <Sun className="size-4" /> : <Moon className="size-4" />}
              </Button>
            </div>
          </div>

          {/* Hero Section */}
          <div className="mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2 text-balance">
              Encuentra tu espacio de estudio ideal
            </h2>
            <p className="text-muted-foreground mb-6">
              Las mejores opciones cerca de ti, actualizadas en tiempo real
            </p>

            {/* Quick Stats */}
            <div className="flex flex-wrap gap-4 mb-6">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <BookOpen className="size-4 text-primary" />
                </div>
                <span><span className="font-semibold text-foreground">127</span> bibliotecas</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="size-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                  <Clock className="size-4 text-emerald-600 dark:text-emerald-400" />
                </div>
                <span><span className="font-semibold text-foreground">43</span> abiertas ahora</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="size-8 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <Users className="size-4 text-blue-600 dark:text-blue-400" />
                </div>
                <span><span className="font-semibold text-foreground">2,340</span> plazas libres</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button className="bg-primary hover:bg-primary/90 gap-2">
                <MapPin className="size-4" />
                Usar mi ubicacion
              </Button>
              <Link href="/listado">
                <Button variant="outline" className="w-full sm:w-auto border-border gap-2">
                  Ver todas las bibliotecas
                  <ArrowRight className="size-4" />
                </Button>
              </Link>
            </div>
          </div>
        </header>

        {/* Top 3 Section */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-foreground">Top 3 opciones para ti</h3>
              <p className="text-sm text-muted-foreground">Basado en tu ubicacion y preferencias</p>
            </div>
            <Link href="/listado">
              <Button variant="ghost" size="sm" className="gap-1 text-primary hover:text-primary/80">
                Ver mas
                <ArrowRight className="size-4" />
              </Button>
            </Link>
          </div>

          <div className="space-y-4">
            {topLibraries.map((library) => (
              <LibraryCard
                key={library.id}
                library={library}
                viewMode={viewMode}
                onNavigate={() => console.log("Navigate to library")}
                onDetails={() => console.log("Show details")}
                onReview={() => openReviewModal(library.name)}
              />
            ))}
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-12 py-8 text-center border-t border-border">
          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <BookOpen className="size-5 text-primary" />
            </div>
            <span className="font-semibold text-foreground">AlaBiblio</span>
          </div>
          <p className="text-sm text-muted-foreground mb-2">
            Proyecto de la Comunidad de Madrid
          </p>
          <p className="text-xs text-muted-foreground">
            Encuentra, compara y valora bibliotecas y salas de estudio
          </p>
        </footer>
      </div>

      {/* Review Modal */}
      <ReviewModal
        isOpen={reviewModal.isOpen}
        onClose={closeReviewModal}
        libraryName={reviewModal.libraryName}
        onSubmit={(review) => console.log("Review submitted:", review)}
      />
    </div>
  )
}
